﻿define("epi-ecf-ui/widget/DeleteCampaignItemDialog", [
// dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/json",
    "dojo/_base/lang",
    "dojo/when",
// epi
    "epi/shell/widget/dialog/Alert",
    "epi/shell/widget/dialog/Confirmation",
    "epi/string",
// epi-ecf-ui
    "../MarketingUtils",
// Resources
    "epi/i18n!epi/nls/episerver.shared",
    "epi/i18n!epi/nls/commerce.widget.marketingitemlist.deleteconfirmation"
], function(
// dojo
    array,
    declare,
    json,
    lang,
    when,
// epi
    Alert,
    Confirmation,
    epiString,
// epi-ecf-ui
    MarketingUtils,
// Resources
    sharedResources,
    resources
) {
    return declare([Confirmation], {
        // summary:
        //      Confirmation dialog asking the user if a campaign item should be deleted.
        // tags:
        //      internal

        cancelActionText: sharedResources.action.cancel,

        confirmActionText: sharedResources.action.deletelabel,

        destroyOnHide: true,

        setFocusOnConfirmButton: false,

        contentData: null,

        store: null,

        resources: null,

        postMixInProperties: function(){
            this.inherited(arguments);
            if (!this.contentData){
                throw new Error("you need to set the contentData property");
            }
            if (!this.store){
                throw new Error("you need to set a store");
            }
        },

        getActions: function(){
            var actions = this.inherited(arguments);
            var confirmAction, cancelAction;
            array.forEach(actions, function(action){
                if (action.label === this.confirmActionText){
                    confirmAction = action;
                } else if (action.label === this.cancelActionText){
                    cancelAction = action;
                }
            }, this);

            if (this.setFocusOnConfirmButton) {
                confirmAction.settings = { "class": "Salt" };
            } else {
                cancelAction.settings = { "class": "Salt", firstFocusable: true };
            }
            return actions;
        },

        onAction: function(ok){
            if (ok){
                when(this.store.remove(this.contentData.contentLink),
                    lang.hitch(this, function () {
                        this.store.updateDependentStores(this.contentData);
                    }),
                    function (errorResponse) {
                        var message = json.fromJson(errorResponse.responseText)[0].errorMessage;

                        var alertDialog = new Alert({
                            description: epiString.toHTML(message),
                            destroyOnHide: true
                        });

                        alertDialog.show();
                    }
                );
            }
        },

        _setContentDataAttr: function(contentData){
            this._setResources(contentData.typeIdentifier);
            this.set("title", this.resources.title);
            var description = this.resources[MarketingUtils.getStatusString(contentData.properties.status)];
            if (contentData.hasChildren){
                description = this._appendText(description, this.resources.childreninfo);
            }
            this.set("description", this._appendText(description, resources.noretreatnosurrender));
            this.contentData = contentData;
        },

        _setResources: function(typeIdentifier){
            if (MarketingUtils.isSalesCampaign(typeIdentifier)) {
                this.resources = resources.campaign;
            } else if (MarketingUtils.isPromotionData(typeIdentifier)) {
                this.resources = resources.promotiondata;
            } else {
                throw new Error("This dialog only accepts campaigns and promotions");
            }
        },

        _appendText: function(originalText, textToAppend){
            return !!originalText ? lang.replace("{0}<br /><br />{1}", [originalText, textToAppend]) : textToAppend;
        }
    });
});
