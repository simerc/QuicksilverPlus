﻿define("epi-ecf-ui/FacetFiltersService", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/json",
    "dojo/_base/lang",
//dijit
    "dijit/Destroyable",
// epi
    "epi/dependency",
    "epi/UriParser"
], function (
// dojo
    declare,
    json,
    lang,
// dijit
    Destroyable,
// epi
    dependency,
    UriParser
) {

    return declare([Destroyable], {
        // summary:
        //      Helper class used to manages the facet filters.
        // tags:
        //      public

        // hashKey: [public] string
        //      Key used in url to holds all information about facet filters.
        hashKey: null,

        _groupSeparator: "|",
        _itemSeparator: ";",

        constructor: function (params) {
            declare.safeMixin(this, params);

            this._hashWrapper = this._hashWrapper || dependency.resolve("epi.shell.HashWrapper");

            this.hashKey = this.hashKey || "facets";
        },

        getFiltersAsJson: function (baseFilter, baseFilterOnly) {
            // summary:
            //      Gets facet filters string in JSON format from url.
            // baseFilter: [Object]
            //      Required condition to applies to the filters.
            // baseFilterOnly: [bool]
            //      Flag indicates that should use baseFilter object to builder query only.
            // returns: [string]
            //      Facet filters string in JSON format.
            // tags:
            //      public

            var filtersObject = {};
            if (!baseFilterOnly) {
                this.getFilters().forEach(function (item, index) {
                    filtersObject[item.id] = item.values;
                });
            }

            var values = baseFilter && baseFilter.values;
            if ((values instanceof Array) && values[0] != null) {
                filtersObject[baseFilter.id] = values;
                if (values[0] === "") {
                    filtersObject.hasOwnProperty(baseFilter.id) && delete filtersObject[baseFilter.id];
                }
            }

            return json.toJson(filtersObject);
        },

        getFilters: function () {
            // summary:
            //      Gets facet filters object from url.
            // returns: [Array]
            //      Collection of object in { id: [string], values: [Array] } format.
            // tags:
            //      public

            var hash = this._hashWrapper.getHash();
            if (hash && hash.hasOwnProperty(this.hashKey)) {
                return this.hashTokenToFilters(hash[this.hashKey]);
            }

            return [];
        },

        updateFilters: function (newFilters) {
            // summary:
            //      Updates facet filter conditions.
            // newFilters: [Object]
            //      New facet filter conditions object.
            // tags:
            //      public

            var hash = this._hashWrapper.getHash();
            if (hash && hash.hasOwnProperty(this.hashKey)) {
                delete hash[this.hashKey];
            }

            this._hashWrapper.setHash(lang.delegate(newFilters, hash));
        },

        hashTokenToFilters: function (hashToken) {
            // summary:
            //      Converts the given hash token string to a facet filters array.
            // hashToken: [string]
            //      Hash string that holds all information about facet filters.
            // returns: [Array]
            //      Collection of object in { id: [string], values: [Array] } format.
            // tags:
            //      public

            var filters = [];
            hashToken && hashToken.split(this._groupSeparator).forEach(function (item, index) {
                var uri = UriParser(item),
                    itemType = uri.getType(),
                    itemId = uri.getId();
                if (!!itemType && !!itemId) {
                    filters.push({
                        "id": itemType,
                        values: itemId.split(this._itemSeparator)
                    });
                }
            }, this);

            return filters;
        },

        filtersToHash: function (filters) {
            // summary:
            //      Converts the given facet filters array to a hash token string.
            // filters: [Array]
            //      Collection of object in { id: [string], values: [Array] } format.
            // returns: [Object]
            //      Facet filters in format of hash object.
            // tags:
            //      public

            var hashItems = [];
            filters.filter(function (item, index) {
                var hasValue = (item.values instanceof Array) && item.values.length > 0;
                if (hasValue) {
                    hashItems.push(item.id + ":///" + item.values.join(this._itemSeparator));
                }

                return hasValue;
            }, this);

            var hash = {};
            if (hashItems.length > 0) {
                hash[this.hashKey] = hashItems.join(this._groupSeparator);
            }

            return hash;
        }

    });

});